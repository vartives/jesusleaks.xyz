﻿using System;

// Token: 0x0200000B RID: 11
internal class <Module>{168AE944-632F-4E44-A8B8-499BB4D2DF61}
{
}
