﻿using System;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

// Token: 0x02000004 RID: 4
internal class Class0
{
	// Token: 0x06000004 RID: 4 RVA: 0x00002248 File Offset: 0x00000448
	internal JObject method_0(string string_0, WebHeaderCollection webHeaderCollection_0)
	{
		return JObject.Parse(new WebClient
		{
			Headers = webHeaderCollection_0
		}.DownloadString("https://toomanyaccounts.org/" + string_0));
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000256C File Offset: 0x0000076C
	internal async Task<JObject> method_1(string string_0, WebHeaderCollection webHeaderCollection_0)
	{
		TaskAwaiter<string> taskAwaiter = new WebClient
		{
			Headers = webHeaderCollection_0
		}.DownloadStringTaskAsync("https://toomanyaccounts.org/" + string_0).GetAwaiter();
		if (!taskAwaiter.IsCompleted)
		{
			await taskAwaiter;
			TaskAwaiter<string> taskAwaiter2;
			taskAwaiter = taskAwaiter2;
			taskAwaiter2 = default(TaskAwaiter<string>);
		}
		return JObject.Parse(taskAwaiter.GetResult());
	}
}
