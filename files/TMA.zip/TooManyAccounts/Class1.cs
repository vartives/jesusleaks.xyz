﻿using System;
using System.IO;
using System.Reflection;
using UnityEngine;

// Token: 0x02000006 RID: 6
internal class Class1
{
	// Token: 0x06000008 RID: 8 RVA: 0x000026B4 File Offset: 0x000008B4
	internal static string smethod_0()
	{
		string text = File.ReadAllText(Class1.string_2);
		if (text.Contains("HideManagerGameObject = false"))
		{
			File.WriteAllText(Class1.string_2, text.Replace("HideManagerGameObject = false", "HideManagerGameObject = true"));
			Application.Quit();
			return "";
		}
		foreach (string text2 in Directory.GetFiles(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)))
		{
			if (text2.EndsWith(".txt"))
			{
				string text3 = File.ReadAllText(text2);
				if (text3.Length < 40)
				{
					Class1.string_5 = text2;
					Class1.string_0 = text3.Trim();
				}
				else
				{
					Class1.string_4 = text2;
					Class1.string_1 = text3;
				}
			}
		}
		if (Class1.string_4 == "" || Class1.string_5 == "")
		{
			return "nofile";
		}
		if (!(Class1.string_0 == "") && !(Class1.string_1 == ""))
		{
			return "good";
		}
		return "emptyfile";
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000027D0 File Offset: 0x000009D0
	internal static void smethod_1(string string_6)
	{
		Class1.string_1 = string_6;
		File.WriteAllText(Class1.string_4, Class1.string_1);
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000027F4 File Offset: 0x000009F4
	internal static void smethod_2(string string_6)
	{
		Class1.string_0 = string_6;
		File.WriteAllText(Class1.string_5, Class1.string_0);
	}

	// Token: 0x04000007 RID: 7
	internal static string string_0;

	// Token: 0x04000008 RID: 8
	internal static string string_1;

	// Token: 0x04000009 RID: 9
	internal static string string_2 = "BepInEx\\config\\BepInEx.cfg";

	// Token: 0x0400000A RID: 10
	internal static bool bool_0;

	// Token: 0x0400000B RID: 11
	internal static bool bool_1;

	// Token: 0x0400000C RID: 12
	internal static bool bool_2 = true;

	// Token: 0x0400000D RID: 13
	internal static string string_3;

	// Token: 0x0400000E RID: 14
	internal static Class0 class0_0 = new Class0();

	// Token: 0x0400000F RID: 15
	private static string string_4;

	// Token: 0x04000010 RID: 16
	private static string string_5;
}
