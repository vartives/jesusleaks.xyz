﻿using System;
using System.Reflection;

// Token: 0x0200000C RID: 12
internal class Class2
{
	// Token: 0x06000021 RID: 33 RVA: 0x000032C0 File Offset: 0x000014C0
	internal static void smethod_0(int typemdt)
	{
		Type type = Class2.module_0.ResolveType(33554432 + typemdt);
		foreach (FieldInfo fieldInfo in type.GetFields())
		{
			MethodInfo methodInfo = (MethodInfo)Class2.module_0.ResolveMethod(fieldInfo.MetadataToken + 100663296);
			fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, methodInfo));
		}
	}

	// Token: 0x0400001B RID: 27
	internal static Module module_0 = typeof(Class2).Assembly.ManifestModule;

	// Token: 0x0200000D RID: 13
	// (Invoke) Token: 0x06000025 RID: 37
	internal delegate void Delegate0(object o);
}
