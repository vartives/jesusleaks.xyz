﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

// Token: 0x0200000E RID: 14
internal class Class3
{
	// Token: 0x06000028 RID: 40 RVA: 0x00003360 File Offset: 0x00001560
	static Class3()
	{
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	// Token: 0x06000029 RID: 41 RVA: 0x0000226B File Offset: 0x0000046B
	private void method_0()
	{
	}

	// Token: 0x0600002A RID: 42 RVA: 0x000034FC File Offset: 0x000016FC
	internal static byte[] smethod_0(object object_2)
	{
		uint[] array = new uint[16];
		uint num = (uint)((448 - object_2.Length * 8 % 512 + 512) % 512);
		if (num == 0U)
		{
			num = 512U;
		}
		uint num2 = (uint)((long)object_2.Length + (long)((ulong)(num / 8U)) + 8L);
		ulong num3 = (ulong)((long)object_2.Length * 8L);
		byte[] array2 = new byte[num2];
		for (int i = 0; i < object_2.Length; i++)
		{
			array2[i] = object_2[i];
		}
		byte[] array3 = array2;
		int num4 = object_2.Length;
		array3[num4] |= 128;
		for (int j = 8; j > 0; j--)
		{
			array2[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)((num3 >> (8 - j) * 8) & 255UL);
		}
		uint num5 = (uint)(array2.Length * 8 / 32);
		uint num6 = 1732584193U;
		uint num7 = 4023233417U;
		uint num8 = 2562383102U;
		uint num9 = 271733878U;
		for (uint num10 = 0U; num10 < num5 / 16U; num10 += 1U)
		{
			uint num11 = num10 << 6;
			for (uint num12 = 0U; num12 < 61U; num12 += 4U)
			{
				array[(int)(num12 >> 2)] = (uint)(((int)array2[(int)(num11 + (num12 + 3U))] << 24) | ((int)array2[(int)(num11 + (num12 + 2U))] << 16) | ((int)array2[(int)(num11 + (num12 + 1U))] << 8) | (int)array2[(int)(num11 + num12)]);
			}
			uint num13 = num6;
			uint num14 = num7;
			uint num15 = num8;
			uint num16 = num9;
			Class3.smethod_1(ref num6, num7, num8, num9, 0U, 7, 1U, array);
			Class3.smethod_1(ref num9, num6, num7, num8, 1U, 12, 2U, array);
			Class3.smethod_1(ref num8, num9, num6, num7, 2U, 17, 3U, array);
			Class3.smethod_1(ref num7, num8, num9, num6, 3U, 22, 4U, array);
			Class3.smethod_1(ref num6, num7, num8, num9, 4U, 7, 5U, array);
			Class3.smethod_1(ref num9, num6, num7, num8, 5U, 12, 6U, array);
			Class3.smethod_1(ref num8, num9, num6, num7, 6U, 17, 7U, array);
			Class3.smethod_1(ref num7, num8, num9, num6, 7U, 22, 8U, array);
			Class3.smethod_1(ref num6, num7, num8, num9, 8U, 7, 9U, array);
			Class3.smethod_1(ref num9, num6, num7, num8, 9U, 12, 10U, array);
			Class3.smethod_1(ref num8, num9, num6, num7, 10U, 17, 11U, array);
			Class3.smethod_1(ref num7, num8, num9, num6, 11U, 22, 12U, array);
			Class3.smethod_1(ref num6, num7, num8, num9, 12U, 7, 13U, array);
			Class3.smethod_1(ref num9, num6, num7, num8, 13U, 12, 14U, array);
			Class3.smethod_1(ref num8, num9, num6, num7, 14U, 17, 15U, array);
			Class3.smethod_1(ref num7, num8, num9, num6, 15U, 22, 16U, array);
			Class3.smethod_2(ref num6, num7, num8, num9, 1U, 5, 17U, array);
			Class3.smethod_2(ref num9, num6, num7, num8, 6U, 9, 18U, array);
			Class3.smethod_2(ref num8, num9, num6, num7, 11U, 14, 19U, array);
			Class3.smethod_2(ref num7, num8, num9, num6, 0U, 20, 20U, array);
			Class3.smethod_2(ref num6, num7, num8, num9, 5U, 5, 21U, array);
			Class3.smethod_2(ref num9, num6, num7, num8, 10U, 9, 22U, array);
			Class3.smethod_2(ref num8, num9, num6, num7, 15U, 14, 23U, array);
			Class3.smethod_2(ref num7, num8, num9, num6, 4U, 20, 24U, array);
			Class3.smethod_2(ref num6, num7, num8, num9, 9U, 5, 25U, array);
			Class3.smethod_2(ref num9, num6, num7, num8, 14U, 9, 26U, array);
			Class3.smethod_2(ref num8, num9, num6, num7, 3U, 14, 27U, array);
			Class3.smethod_2(ref num7, num8, num9, num6, 8U, 20, 28U, array);
			Class3.smethod_2(ref num6, num7, num8, num9, 13U, 5, 29U, array);
			Class3.smethod_2(ref num9, num6, num7, num8, 2U, 9, 30U, array);
			Class3.smethod_2(ref num8, num9, num6, num7, 7U, 14, 31U, array);
			Class3.smethod_2(ref num7, num8, num9, num6, 12U, 20, 32U, array);
			Class3.smethod_3(ref num6, num7, num8, num9, 5U, 4, 33U, array);
			Class3.smethod_3(ref num9, num6, num7, num8, 8U, 11, 34U, array);
			Class3.smethod_3(ref num8, num9, num6, num7, 11U, 16, 35U, array);
			Class3.smethod_3(ref num7, num8, num9, num6, 14U, 23, 36U, array);
			Class3.smethod_3(ref num6, num7, num8, num9, 1U, 4, 37U, array);
			Class3.smethod_3(ref num9, num6, num7, num8, 4U, 11, 38U, array);
			Class3.smethod_3(ref num8, num9, num6, num7, 7U, 16, 39U, array);
			Class3.smethod_3(ref num7, num8, num9, num6, 10U, 23, 40U, array);
			Class3.smethod_3(ref num6, num7, num8, num9, 13U, 4, 41U, array);
			Class3.smethod_3(ref num9, num6, num7, num8, 0U, 11, 42U, array);
			Class3.smethod_3(ref num8, num9, num6, num7, 3U, 16, 43U, array);
			Class3.smethod_3(ref num7, num8, num9, num6, 6U, 23, 44U, array);
			Class3.smethod_3(ref num6, num7, num8, num9, 9U, 4, 45U, array);
			Class3.smethod_3(ref num9, num6, num7, num8, 12U, 11, 46U, array);
			Class3.smethod_3(ref num8, num9, num6, num7, 15U, 16, 47U, array);
			Class3.smethod_3(ref num7, num8, num9, num6, 2U, 23, 48U, array);
			Class3.smethod_4(ref num6, num7, num8, num9, 0U, 6, 49U, array);
			Class3.smethod_4(ref num9, num6, num7, num8, 7U, 10, 50U, array);
			Class3.smethod_4(ref num8, num9, num6, num7, 14U, 15, 51U, array);
			Class3.smethod_4(ref num7, num8, num9, num6, 5U, 21, 52U, array);
			Class3.smethod_4(ref num6, num7, num8, num9, 12U, 6, 53U, array);
			Class3.smethod_4(ref num9, num6, num7, num8, 3U, 10, 54U, array);
			Class3.smethod_4(ref num8, num9, num6, num7, 10U, 15, 55U, array);
			Class3.smethod_4(ref num7, num8, num9, num6, 1U, 21, 56U, array);
			Class3.smethod_4(ref num6, num7, num8, num9, 8U, 6, 57U, array);
			Class3.smethod_4(ref num9, num6, num7, num8, 15U, 10, 58U, array);
			Class3.smethod_4(ref num8, num9, num6, num7, 6U, 15, 59U, array);
			Class3.smethod_4(ref num7, num8, num9, num6, 13U, 21, 60U, array);
			Class3.smethod_4(ref num6, num7, num8, num9, 4U, 6, 61U, array);
			Class3.smethod_4(ref num9, num6, num7, num8, 11U, 10, 62U, array);
			Class3.smethod_4(ref num8, num9, num6, num7, 2U, 15, 63U, array);
			Class3.smethod_4(ref num7, num8, num9, num6, 9U, 21, 64U, array);
			num6 += num13;
			num7 += num14;
			num8 += num15;
			num9 += num16;
		}
		byte[] array4 = new byte[16];
		Array.Copy(BitConverter.GetBytes(num6), 0, array4, 0, 4);
		Array.Copy(BitConverter.GetBytes(num7), 0, array4, 4, 4);
		Array.Copy(BitConverter.GetBytes(num8), 0, array4, 8, 4);
		Array.Copy(BitConverter.GetBytes(num9), 0, array4, 12, 4);
		return array4;
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002287 File Offset: 0x00000487
	private static void smethod_1(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_2)
	{
		uint_1 = uint_2 + Class3.smethod_5(uint_1 + ((uint_2 & uint_3) | (~uint_2 & uint_4)) + object_2[(int)uint_5] + Class3.uint_0[(int)(uint_6 - 1U)], ushort_0);
	}

	// Token: 0x0600002C RID: 44 RVA: 0x000022B0 File Offset: 0x000004B0
	private static void smethod_2(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_2)
	{
		uint_1 = uint_2 + Class3.smethod_5(uint_1 + ((uint_2 & uint_4) | (uint_3 & ~uint_4)) + object_2[(int)uint_5] + Class3.uint_0[(int)(uint_6 - 1U)], ushort_0);
	}

	// Token: 0x0600002D RID: 45 RVA: 0x000022D9 File Offset: 0x000004D9
	private static void smethod_3(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_2)
	{
		uint_1 = uint_2 + Class3.smethod_5(uint_1 + (uint_2 ^ uint_3 ^ uint_4) + object_2[(int)uint_5] + Class3.uint_0[(int)(uint_6 - 1U)], ushort_0);
	}

	// Token: 0x0600002E RID: 46 RVA: 0x000022FF File Offset: 0x000004FF
	private static void smethod_4(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_2)
	{
		uint_1 = uint_2 + Class3.smethod_5(uint_1 + (uint_3 ^ (uint_2 | ~uint_4)) + object_2[(int)uint_5] + Class3.uint_0[(int)(uint_6 - 1U)], ushort_0);
	}

	// Token: 0x0600002F RID: 47 RVA: 0x00002326 File Offset: 0x00000526
	private static uint smethod_5(uint uint_1, ushort ushort_0)
	{
		return (uint_1 >> (int)(32 - ushort_0)) | (uint_1 << (int)ushort_0);
	}

	// Token: 0x06000030 RID: 48 RVA: 0x00002338 File Offset: 0x00000538
	internal static bool smethod_6()
	{
		if (!Class3.bool_2)
		{
			Class3.smethod_8();
			Class3.bool_2 = true;
		}
		return Class3.bool_5;
	}

	// Token: 0x06000031 RID: 49 RVA: 0x00002351 File Offset: 0x00000551
	internal Class3()
	{
	}

	// Token: 0x06000032 RID: 50 RVA: 0x00003B5C File Offset: 0x00001D5C
	private void method_1(byte[] byte_2, byte[] byte_3, byte[] byte_4)
	{
		int num = byte_4.Length % 4;
		int num2 = byte_4.Length / 4;
		byte[] array = new byte[byte_4.Length];
		int num3 = byte_2.Length / 4;
		uint num4 = 0U;
		if (num > 0)
		{
			num2++;
		}
		for (int i = 0; i < num2; i++)
		{
			int num5 = i % num3;
			int num6 = i * 4;
			uint num7 = (uint)(num5 * 4);
			uint num8 = (uint)(((int)byte_2[(int)(num7 + 3U)] << 24) | ((int)byte_2[(int)(num7 + 2U)] << 16) | ((int)byte_2[(int)(num7 + 1U)] << 8) | (int)byte_2[(int)num7]);
			uint num9 = 255U;
			int num10 = 0;
			uint num11;
			if (i == num2 - 1 && num > 0)
			{
				num11 = 0U;
				num4 += num8;
				for (int j = 0; j < num; j++)
				{
					if (j > 0)
					{
						num11 <<= 8;
					}
					num11 |= (uint)byte_4[byte_4.Length - (1 + j)];
				}
			}
			else
			{
				num4 += num8;
				num7 = (uint)num6;
				num11 = (uint)(((int)byte_4[(int)(num7 + 3U)] << 24) | ((int)byte_4[(int)(num7 + 2U)] << 16) | ((int)byte_4[(int)(num7 + 1U)] << 8) | (int)byte_4[(int)num7]);
			}
			uint num13;
			uint num12 = (num13 = num4);
			num13 ^= num13 << 7;
			num13 += 175865741U;
			num13 ^= num13 << 25;
			num13 += 4180829584U;
			num13 ^= num13 >> 1;
			num13 += 4007474699U;
			num13 = 1398983127U - num13;
			num4 = num12 + (uint)num13;
			if (i == num2 - 1 && num > 0)
			{
				uint num14 = num4 ^ num11;
				for (int k = 0; k < num; k++)
				{
					if (k > 0)
					{
						num9 <<= 8;
						num10 += 8;
					}
					array[num6 + k] = (byte)((num14 & num9) >> num10);
				}
			}
			else
			{
				uint num15 = num4 ^ num11;
				array[num6] = (byte)(num15 & 255U);
				array[num6 + 1] = (byte)((num15 & 65280U) >> 8);
				array[num6 + 2] = (byte)((num15 & 16711680U) >> 16);
				array[num6 + 3] = (byte)((num15 & 4278190080U) >> 24);
			}
		}
		Class3.byte_1 = array;
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00003D70 File Offset: 0x00001F70
	internal static SymmetricAlgorithm smethod_7()
	{
		SymmetricAlgorithm symmetricAlgorithm = null;
		if (Class3.smethod_6())
		{
			symmetricAlgorithm = new AesCryptoServiceProvider();
		}
		else
		{
			try
			{
				symmetricAlgorithm = new RijndaelManaged();
			}
			catch
			{
				symmetricAlgorithm = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
			}
		}
		return symmetricAlgorithm;
	}

	// Token: 0x06000034 RID: 52 RVA: 0x00003DC8 File Offset: 0x00001FC8
	internal static void smethod_8()
	{
		try
		{
			Class3.bool_5 = CryptoConfig.AllowOnlyFipsAlgorithms;
		}
		catch
		{
		}
	}

	// Token: 0x06000035 RID: 53 RVA: 0x00002359 File Offset: 0x00000559
	internal static byte[] smethod_9(byte[] byte_2)
	{
		if (!Class3.smethod_6())
		{
			return new MD5CryptoServiceProvider().ComputeHash(byte_2);
		}
		return Class3.smethod_0(byte_2);
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00003DF4 File Offset: 0x00001FF4
	internal static void smethod_10(HashAlgorithm hashAlgorithm_0, Stream stream_0, uint uint_1, byte[] byte_2)
	{
		while (uint_1 > 0U)
		{
			int num = ((uint_1 > (uint)byte_2.Length) ? byte_2.Length : ((int)uint_1));
			stream_0.Read(byte_2, 0, num);
			Class3.smethod_11(hashAlgorithm_0, byte_2, 0, num);
			uint_1 -= (uint)num;
		}
	}

	// Token: 0x06000037 RID: 55 RVA: 0x00002374 File Offset: 0x00000574
	internal static void smethod_11(HashAlgorithm hashAlgorithm_0, byte[] byte_2, int int_6, int int_7)
	{
		hashAlgorithm_0.TransformBlock(byte_2, int_6, int_7, byte_2, int_6);
	}

	// Token: 0x06000038 RID: 56 RVA: 0x00003E30 File Offset: 0x00002030
	internal static uint smethod_12(uint uint_1, int int_6, long long_2, BinaryReader binaryReader_0)
	{
		for (int i = 0; i < int_6; i++)
		{
			binaryReader_0.BaseStream.Position = long_2 + (long)(i * 40 + 8);
			uint num = binaryReader_0.ReadUInt32();
			uint num2 = binaryReader_0.ReadUInt32();
			binaryReader_0.ReadUInt32();
			uint num3 = binaryReader_0.ReadUInt32();
			if (num2 <= uint_1 && uint_1 < num2 + num)
			{
				return num3 + uint_1 - num2;
			}
		}
		return 0U;
	}

	// Token: 0x06000039 RID: 57 RVA: 0x00002382 File Offset: 0x00000582
	private static uint smethod_13(uint uint_1)
	{
		return (uint)"{11111-22222-10009-11112}".Length;
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00003E8C File Offset: 0x0000208C
	private static void yBdWeaxmql(Stream stream_0, int int_6)
	{
		Class3.Class6 @class = new Class3.Class6(stream_0);
		@class.method_0().Position = 0L;
		byte[] array = @class.method_1((int)@class.method_0().Length);
		@class.method_4();
		byte[] array2 = new byte[32];
		array2[0] = 86;
		array2[0] = 123;
		array2[0] = 156;
		array2[0] = 88;
		array2[0] = 98;
		array2[0] = 114;
		array2[1] = 166;
		array2[1] = 154;
		array2[1] = 126;
		array2[1] = 207;
		array2[2] = 29;
		array2[2] = 143;
		array2[2] = 139;
		array2[3] = 154;
		array2[3] = 94;
		array2[3] = 189;
		array2[4] = 228;
		array2[4] = 179;
		array2[4] = 88;
		array2[4] = 76;
		array2[5] = 120;
		array2[5] = 85;
		array2[5] = 123;
		array2[5] = 169;
		array2[5] = 62;
		array2[6] = 90;
		array2[6] = 63;
		array2[6] = 184;
		array2[7] = 142;
		array2[7] = 97;
		array2[7] = 160;
		array2[7] = 210;
		array2[7] = 118;
		array2[7] = 234;
		array2[8] = 127;
		array2[8] = 168;
		array2[8] = 25;
		array2[8] = 213;
		array2[9] = 158;
		array2[9] = 71;
		array2[9] = 181;
		array2[9] = 130;
		array2[9] = 233;
		array2[10] = 62;
		array2[10] = 141;
		array2[10] = 112;
		array2[10] = 19;
		array2[10] = 92;
		array2[11] = 131;
		array2[11] = 110;
		array2[11] = 162;
		array2[11] = 116;
		array2[11] = 55;
		array2[12] = 131;
		array2[12] = 218;
		array2[12] = 99;
		array2[12] = 105;
		array2[13] = 116;
		array2[13] = 90;
		array2[13] = 165;
		array2[13] = 139;
		array2[13] = 65;
		array2[14] = 148;
		array2[14] = 142;
		array2[14] = 167;
		array2[14] = 100;
		array2[14] = 133;
		array2[14] = 168;
		array2[15] = 154;
		array2[15] = 94;
		array2[15] = 205;
		array2[15] = 123;
		array2[15] = 157;
		array2[16] = 116;
		array2[16] = 139;
		array2[16] = 173;
		array2[16] = 100;
		array2[16] = 106;
		array2[17] = 121;
		array2[17] = 88;
		array2[17] = 124;
		array2[17] = 180;
		array2[18] = 105;
		array2[18] = 85;
		array2[18] = 138;
		array2[18] = 5;
		array2[19] = 45;
		array2[19] = 114;
		array2[19] = 61;
		array2[20] = 155;
		array2[20] = 91;
		array2[20] = 2;
		array2[21] = 122;
		array2[21] = 139;
		array2[21] = 86;
		array2[21] = 10;
		array2[22] = 162;
		array2[22] = 111;
		array2[22] = 109;
		array2[22] = 6;
		array2[23] = 87;
		array2[23] = 158;
		array2[23] = 125;
		array2[23] = 108;
		array2[24] = 113;
		array2[24] = 89;
		array2[24] = 148;
		array2[24] = 7;
		array2[25] = 110;
		array2[25] = 174;
		array2[25] = 192;
		array2[25] = 118;
		array2[25] = 138;
		array2[25] = 64;
		array2[26] = 96;
		array2[26] = 199;
		array2[26] = 107;
		array2[26] = 144;
		array2[27] = 79;
		array2[27] = 140;
		array2[27] = 91;
		array2[27] = 196;
		array2[27] = 90;
		array2[27] = 25;
		array2[28] = 190;
		array2[28] = 83;
		array2[28] = 131;
		array2[29] = 181;
		array2[29] = 89;
		array2[29] = 154;
		array2[29] = 190;
		array2[30] = 126;
		array2[30] = 136;
		array2[30] = 98;
		array2[30] = 108;
		array2[30] = 131;
		array2[30] = 211;
		array2[31] = 65;
		array2[31] = 83;
		array2[31] = 8;
		array2[31] = 40;
		byte[] array3 = array2;
		byte[] array4 = new byte[16];
		array4[0] = 86;
		array4[0] = 88;
		array4[0] = 119;
		array4[0] = 62;
		array4[0] = 144;
		array4[0] = 251;
		array4[1] = 166;
		array4[1] = 154;
		array4[1] = 126;
		array4[1] = 124;
		array4[1] = 88;
		array4[1] = 145;
		array4[2] = 116;
		array4[2] = 142;
		array4[2] = 51;
		array4[3] = 177;
		array4[3] = 148;
		array4[3] = 143;
		array4[3] = 88;
		array4[3] = 31;
		array4[4] = 101;
		array4[4] = 85;
		array4[4] = 123;
		array4[4] = 168;
		array4[5] = 96;
		array4[5] = 114;
		array4[5] = 90;
		array4[5] = 64;
		array4[6] = 142;
		array4[6] = 47;
		array4[6] = 198;
		array4[6] = 165;
		array4[6] = 25;
		array4[7] = 87;
		array4[7] = 72;
		array4[7] = 142;
		array4[7] = 122;
		array4[7] = 190;
		array4[8] = 129;
		array4[8] = 97;
		array4[8] = 140;
		array4[8] = 129;
		array4[8] = 85;
		array4[8] = 78;
		array4[9] = 109;
		array4[9] = 154;
		array4[9] = 173;
		array4[10] = 106;
		array4[10] = 131;
		array4[10] = 89;
		array4[10] = 146;
		array4[10] = 125;
		array4[10] = 135;
		array4[11] = 93;
		array4[11] = 131;
		array4[11] = 161;
		array4[11] = 58;
		array4[12] = 99;
		array4[12] = 53;
		array4[12] = 89;
		array4[12] = 114;
		array4[12] = 162;
		array4[12] = 75;
		array4[13] = 183;
		array4[13] = 144;
		array4[13] = 167;
		array4[13] = 136;
		array4[13] = 76;
		array4[14] = 132;
		array4[14] = 138;
		array4[14] = 21;
		array4[15] = 100;
		array4[15] = 84;
		array4[15] = 138;
		byte[] array5 = array4;
		Array.Reverse(array5);
		byte[] publicKeyToken = Class3.assembly_0.GetName().GetPublicKeyToken();
		if (publicKeyToken != null && publicKeyToken.Length != 0)
		{
			array5[1] = publicKeyToken[0];
			array5[3] = publicKeyToken[1];
			array5[5] = publicKeyToken[2];
			array5[7] = publicKeyToken[3];
			array5[9] = publicKeyToken[4];
			array5[11] = publicKeyToken[5];
			array5[13] = publicKeyToken[6];
			array5[15] = publicKeyToken[7];
		}
		for (int i = 0; i < array5.Length; i++)
		{
			array3[i] ^= array5[i];
		}
		if (int_6 == -1)
		{
			SymmetricAlgorithm symmetricAlgorithm = Class3.smethod_7();
			symmetricAlgorithm.Mode = CipherMode.CBC;
			ICryptoTransform cryptoTransform = symmetricAlgorithm.CreateDecryptor(array3, array5);
			Stream stream = new MemoryStream();
			CryptoStream cryptoStream = new CryptoStream(stream, cryptoTransform, CryptoStreamMode.Write);
			cryptoStream.Write(array, 0, array.Length);
			cryptoStream.FlushFinalBlock();
			Class3.byte_1 = Class3.smethod_26(stream);
			stream.Close();
			cryptoStream.Close();
			array = Class3.byte_1;
		}
		if (Class3.assembly_0.EntryPoint == null)
		{
			Class3.int_0 = 80;
		}
		new Class3().method_1(array3, array5, array);
	}

	// Token: 0x0600003B RID: 59 RVA: 0x00004B30 File Offset: 0x00002D30
	internal static string smethod_14(string string_2)
	{
		"{11111-22222-50001-00000}".Trim();
		byte[] array = Convert.FromBase64String(string_2);
		return Encoding.Unicode.GetString(array, 0, array.Length);
	}

	// Token: 0x0600003C RID: 60 RVA: 0x0000238E File Offset: 0x0000058E
	private static int smethod_15()
	{
		return 5;
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00004B60 File Offset: 0x00002D60
	private static void smethod_16()
	{
		try
		{
			RSACryptoServiceProvider.UseMachineKeyStore = true;
		}
		catch
		{
		}
	}

	// Token: 0x0600003E RID: 62 RVA: 0x00004B88 File Offset: 0x00002D88
	private static Delegate smethod_17(IntPtr intptr_4, Type type_0)
	{
		return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[]
		{
			typeof(IntPtr),
			typeof(Type)
		}).Invoke(null, new object[] { intptr_4, type_0 });
	}

	// Token: 0x0600003F RID: 63 RVA: 0x00004BE8 File Offset: 0x00002DE8
	internal static object smethod_18(Assembly assembly_1)
	{
		try
		{
			if (File.Exists(((Assembly)assembly_1).Location))
			{
				return ((Assembly)assembly_1).Location;
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(((Assembly)assembly_1).GetName().CodeBase.ToString().Replace("file:///", "")))
			{
				return ((Assembly)assembly_1).GetName().CodeBase.ToString().Replace("file:///", "");
			}
		}
		catch
		{
		}
		try
		{
			if (File.Exists(assembly_1.GetType().GetProperty("Location").GetValue(assembly_1, new object[0])
				.ToString()))
			{
				return assembly_1.GetType().GetProperty("Location").GetValue(assembly_1, new object[0])
					.ToString();
			}
		}
		catch
		{
		}
		return "";
	}

	// Token: 0x06000040 RID: 64
	[DllImport("kernel32")]
	public static extern IntPtr LoadLibrary(string string_2);

	// Token: 0x06000041 RID: 65
	[DllImport("kernel32", CharSet = CharSet.Ansi)]
	public static extern IntPtr GetProcAddress(IntPtr intptr_4, string string_2);

	// Token: 0x06000042 RID: 66 RVA: 0x00004CF8 File Offset: 0x00002EF8
	private static IntPtr smethod_19(IntPtr intptr_4, string string_2, uint uint_1)
	{
		if (Class3.delegate4_0 == null)
		{
			Class3.delegate4_0 = (Class3.Delegate4)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Find ".Trim() + "ResourceA"), typeof(Class3.Delegate4));
		}
		return Class3.delegate4_0(intptr_4, string_2, uint_1);
	}

	// Token: 0x06000043 RID: 67 RVA: 0x00004D50 File Offset: 0x00002F50
	private static IntPtr smethod_20(IntPtr intptr_4, uint uint_1, uint uint_2, uint uint_3)
	{
		if (Class3.delegate5_0 == null)
		{
			Class3.delegate5_0 = (Class3.Delegate5)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Virtual ".Trim() + "Alloc"), typeof(Class3.Delegate5));
		}
		return Class3.delegate5_0(intptr_4, uint_1, uint_2, uint_3);
	}

	// Token: 0x06000044 RID: 68 RVA: 0x00004DAC File Offset: 0x00002FAC
	private static int smethod_21(IntPtr intptr_4, IntPtr intptr_5, [In] [Out] byte[] byte_2, uint uint_1, out IntPtr intptr_6)
	{
		if (Class3.delegate6_0 == null)
		{
			Class3.delegate6_0 = (Class3.Delegate6)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Write ".Trim() + "Process ".Trim() + "Memory"), typeof(Class3.Delegate6));
		}
		return Class3.delegate6_0(intptr_4, intptr_5, byte_2, uint_1, out intptr_6);
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00004E14 File Offset: 0x00003014
	private static int smethod_22(IntPtr intptr_4, int int_6, int int_7, ref int int_8)
	{
		if (Class3.delegate7_0 == null)
		{
			Class3.delegate7_0 = (Class3.Delegate7)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Virtual ".Trim() + "Protect"), typeof(Class3.Delegate7));
		}
		return Class3.delegate7_0(intptr_4, int_6, int_7, ref int_8);
	}

	// Token: 0x06000046 RID: 70 RVA: 0x00004E70 File Offset: 0x00003070
	private static IntPtr MjkWlZoqk3(uint uint_1, int int_6, uint uint_2)
	{
		if (Class3.delegate8_0 == null)
		{
			Class3.delegate8_0 = (Class3.Delegate8)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Open ".Trim() + "Process"), typeof(Class3.Delegate8));
		}
		return Class3.delegate8_0(uint_1, int_6, uint_2);
	}

	// Token: 0x06000047 RID: 71 RVA: 0x00004EC8 File Offset: 0x000030C8
	private static int smethod_23(IntPtr intptr_4)
	{
		if (Class3.delegate9_0 == null)
		{
			Class3.delegate9_0 = (Class3.Delegate9)Marshal.GetDelegateForFunctionPointer(Class3.GetProcAddress(Class3.smethod_24(), "Close ".Trim() + "Handle"), typeof(Class3.Delegate9));
		}
		return Class3.delegate9_0(intptr_4);
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00002391 File Offset: 0x00000591
	private static IntPtr smethod_24()
	{
		if (Class3.intptr_0 == IntPtr.Zero)
		{
			Class3.intptr_0 = Class3.LoadLibrary("kernel ".Trim() + "32.dll");
		}
		return Class3.intptr_0;
	}

	// Token: 0x06000049 RID: 73 RVA: 0x00004F20 File Offset: 0x00003120
	private static byte[] smethod_25(string string_2)
	{
		byte[] array;
		using (FileStream fileStream = new FileStream(string_2, FileMode.Open, FileAccess.Read, FileShare.Read))
		{
			int num = 0;
			int i = (int)fileStream.Length;
			array = new byte[i];
			while (i > 0)
			{
				int num2 = fileStream.Read(array, num, i);
				num += num2;
				i -= num2;
			}
		}
		return array;
	}

	// Token: 0x0600004A RID: 74 RVA: 0x000023C7 File Offset: 0x000005C7
	internal static byte[] smethod_26(MemoryStream memoryStream_0)
	{
		return ((MemoryStream)memoryStream_0).ToArray();
	}

	// Token: 0x0600004B RID: 75 RVA: 0x00004F80 File Offset: 0x00003180
	private static byte[] smethod_27(byte[] byte_2)
	{
		Stream stream = new MemoryStream();
		SymmetricAlgorithm symmetricAlgorithm = Class3.smethod_7();
		symmetricAlgorithm.Key = new byte[]
		{
			34, 191, 201, 168, 98, 128, 48, 147, 78, 52,
			211, 36, 167, 107, 125, 19, 172, 147, 105, 95,
			253, 122, 30, 112, 137, 187, 53, 29, 138, 219,
			95, 157
		};
		symmetricAlgorithm.IV = new byte[]
		{
			159, 188, 238, 100, 126, 6, 239, 164, 137, 236,
			228, 90, 4, 206, 124, 215
		};
		CryptoStream cryptoStream = new CryptoStream(stream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
		cryptoStream.Write(byte_2, 0, byte_2.Length);
		cryptoStream.Close();
		return Class3.smethod_26(stream);
	}

	// Token: 0x0600004C RID: 76 RVA: 0x00004FEC File Offset: 0x000031EC
	private unsafe static int smethod_28(object object_2)
	{
		char* ptr = object_2;
		if (ptr != null)
		{
			ptr += RuntimeHelpers.OffsetToStringData / 2;
		}
		int num = 5381;
		int num2 = 5381;
		char* ptr2 = ptr;
		int num3;
		while ((num3 = (int)(*ptr2)) != 0)
		{
			num = ((num << 5) + num) ^ num3;
			num3 = (int)ptr2[1];
			if (num3 == 0)
			{
				break;
			}
			num2 = ((num2 << 5) + num2) ^ num3;
			ptr2 += 2;
		}
		return num + num2 * 1566083941;
	}

	// Token: 0x0600004D RID: 77 RVA: 0x00005054 File Offset: 0x00003254
	internal static bool smethod_29(string string_2, string string_3)
	{
		if (string_2 == string_3)
		{
			return true;
		}
		if (string_2 == null || string_3 == null)
		{
			return false;
		}
		bool flag = false;
		bool flag2 = false;
		int num = 0;
		int num2 = 0;
		if (string_2.StartsWith(Class3.string_1))
		{
			flag = true;
			num = (int)(string_2[4] | ((int)string_2[5] << 8) | ((int)string_2[6] << 16) | ((int)string_2[7] << 24));
		}
		if (string_3.StartsWith(Class3.string_1))
		{
			flag2 = true;
			num2 = (int)(string_3[4] | ((int)string_3[5] << 8) | ((int)string_3[6] << 16) | ((int)string_3[7] << 24));
		}
		if (!flag && !flag2)
		{
			return false;
		}
		if (!flag)
		{
			num = Class3.smethod_28(string_2);
		}
		if (!flag2)
		{
			num2 = Class3.smethod_28(string_3);
		}
		return num == num2;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00005110 File Offset: 0x00003310
	private byte[] method_2()
	{
		return null;
	}

	// Token: 0x0600004F RID: 79 RVA: 0x00005110 File Offset: 0x00003310
	private byte[] method_3()
	{
		return null;
	}

	// Token: 0x06000050 RID: 80 RVA: 0x000023D4 File Offset: 0x000005D4
	private byte[] method_4()
	{
		int length = "{11111-22222-20001-00001}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000051 RID: 81 RVA: 0x000023EF File Offset: 0x000005EF
	private byte[] method_5()
	{
		int length = "{11111-22222-20001-00002}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000052 RID: 82 RVA: 0x0000240A File Offset: 0x0000060A
	private byte[] method_6()
	{
		int length = "{11111-22222-30001-00001}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000053 RID: 83 RVA: 0x00002425 File Offset: 0x00000625
	private byte[] method_7()
	{
		int length = "{11111-22222-30001-00002}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000054 RID: 84 RVA: 0x00002440 File Offset: 0x00000640
	internal byte[] method_8()
	{
		int length = "{11111-22222-40001-00001}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000055 RID: 85 RVA: 0x0000245B File Offset: 0x0000065B
	internal byte[] method_9()
	{
		int length = "{11111-22222-40001-00002}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000056 RID: 86 RVA: 0x00002476 File Offset: 0x00000676
	internal byte[] method_10()
	{
		int length = "{11111-22222-50001-00001}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000057 RID: 87 RVA: 0x00002491 File Offset: 0x00000691
	internal byte[] method_11()
	{
		int length = "{11111-22222-50001-00002}".Length;
		return new byte[] { 1, 2 };
	}

	// Token: 0x06000058 RID: 88 RVA: 0x000024AC File Offset: 0x000006AC
	internal static bool smethod_30()
	{
		return null == null;
	}

	// Token: 0x06000059 RID: 89 RVA: 0x000024B2 File Offset: 0x000006B2
	internal static object smethod_31()
	{
		return null;
	}

	// Token: 0x0400001C RID: 28
	private static uint[] uint_0 = new uint[]
	{
		3614090360U, 3905402710U, 606105819U, 3250441966U, 4118548399U, 1200080426U, 2821735955U, 4249261313U, 1770035416U, 2336552879U,
		4294925233U, 2304563134U, 1804603682U, 4254626195U, 2792965006U, 1236535329U, 4129170786U, 3225465664U, 643717713U, 3921069994U,
		3593408605U, 38016083U, 3634488961U, 3889429448U, 568446438U, 3275163606U, 4107603335U, 1163531501U, 2850285829U, 4243563512U,
		1735328473U, 2368359562U, 4294588738U, 2272392833U, 1839030562U, 4259657740U, 2763975236U, 1272893353U, 4139469664U, 3200236656U,
		681279174U, 3936430074U, 3572445317U, 76029189U, 3654602809U, 3873151461U, 530742520U, 3299628645U, 4096336452U, 1126891415U,
		2878612391U, 4237533241U, 1700485571U, 2399980690U, 4293915773U, 2240044497U, 1873313359U, 4264355552U, 2734768916U, 1309151649U,
		4149444226U, 3174756917U, 718787259U, 3951481745U
	};

	// Token: 0x0400001D RID: 29
	internal static RSACryptoServiceProvider rsacryptoServiceProvider_0 = null;

	// Token: 0x0400001E RID: 30
	private static int int_0 = 0;

	// Token: 0x0400001F RID: 31
	private static object object_0 = new object();

	// Token: 0x04000020 RID: 32
	private static List<string> list_0 = null;

	// Token: 0x04000021 RID: 33
	private static byte[] byte_0 = new byte[0];

	// Token: 0x04000022 RID: 34
	private static int[] int_1 = new int[0];

	// Token: 0x04000023 RID: 35
	private static SortedList sortedList_0 = new SortedList();

	// Token: 0x04000024 RID: 36
	internal static Class3.Delegate2 delegate2_0 = null;

	// Token: 0x04000025 RID: 37
	private static bool bool_0 = false;

	// Token: 0x04000026 RID: 38
	private static bool bool_1 = false;

	// Token: 0x04000027 RID: 39
	private static Class3.Delegate7 delegate7_0 = null;

	// Token: 0x04000028 RID: 40
	private static IntPtr intptr_0 = IntPtr.Zero;

	// Token: 0x04000029 RID: 41
	internal static Hashtable hashtable_0 = new Hashtable();

	// Token: 0x0400002A RID: 42
	internal static Class3.Delegate2 delegate2_1 = null;

	// Token: 0x0400002B RID: 43
	private static bool bool_2 = false;

	// Token: 0x0400002C RID: 44
	private static Class3.Delegate6 delegate6_0 = null;

	// Token: 0x0400002D RID: 45
	private static bool bool_3 = false;

	// Token: 0x0400002E RID: 46
	private static List<int> list_1 = null;

	// Token: 0x0400002F RID: 47
	private static int int_2 = 1;

	// Token: 0x04000030 RID: 48
	private static IntPtr intptr_1 = IntPtr.Zero;

	// Token: 0x04000031 RID: 49
	private static long long_0 = 0L;

	// Token: 0x04000032 RID: 50
	private static Class3.Delegate8 delegate8_0 = null;

	// Token: 0x04000033 RID: 51
	private static Class3.Delegate9 delegate9_0 = null;

	// Token: 0x04000034 RID: 52
	private static string[] string_0 = new string[0];

	// Token: 0x04000035 RID: 53
	private static string string_1 = Encoding.Unicode.GetString(new byte[] { 134, 123, 241, 8, 24, 98, 77, 199 });

	// Token: 0x04000036 RID: 54
	private static IntPtr intptr_2 = IntPtr.Zero;

	// Token: 0x04000037 RID: 55
	[Class3.Attribute0(typeof(Class3.Attribute0.Class4<object>[]))]
	private static bool bool_4 = false;

	// Token: 0x04000038 RID: 56
	private static int int_3 = 0;

	// Token: 0x04000039 RID: 57
	private static IntPtr intptr_3 = IntPtr.Zero;

	// Token: 0x0400003A RID: 58
	internal static Assembly assembly_0 = typeof(Class3).Assembly;

	// Token: 0x0400003B RID: 59
	private static Class3.Delegate5 delegate5_0 = null;

	// Token: 0x0400003C RID: 60
	private static long long_1 = 0L;

	// Token: 0x0400003D RID: 61
	private static int int_4 = 0;

	// Token: 0x0400003E RID: 62
	private static byte[] byte_1 = new byte[0];

	// Token: 0x0400003F RID: 63
	private static bool bool_5 = false;

	// Token: 0x04000040 RID: 64
	private static object object_1 = new object();

	// Token: 0x04000041 RID: 65
	private static bool bool_6 = false;

	// Token: 0x04000042 RID: 66
	private static Class3.Delegate4 delegate4_0 = null;

	// Token: 0x04000043 RID: 67
	private static int int_5 = 0;

	// Token: 0x04000044 RID: 68
	private static Dictionary<int, int> dictionary_0 = null;

	// Token: 0x0200000F RID: 15
	// (Invoke) Token: 0x0600005B RID: 91
	private delegate void Delegate1(object o);

	// Token: 0x02000010 RID: 16
	internal class Attribute0 : Attribute
	{
		// Token: 0x0600005E RID: 94 RVA: 0x000024B5 File Offset: 0x000006B5
		public Attribute0(object object_0)
		{
		}

		// Token: 0x02000011 RID: 17
		internal class Class4<T>
		{
			// Token: 0x06000060 RID: 96 RVA: 0x000024BD File Offset: 0x000006BD
			internal static bool smethod_0()
			{
				return Class3.Attribute0.Class4<T>.object_0 == null;
			}

			// Token: 0x06000061 RID: 97 RVA: 0x000024C7 File Offset: 0x000006C7
			internal static object smethod_1()
			{
				return Class3.Attribute0.Class4<T>.object_0;
			}

			// Token: 0x04000045 RID: 69
			internal static object object_0;
		}
	}

	// Token: 0x02000012 RID: 18
	internal class Class5
	{
		// Token: 0x06000062 RID: 98 RVA: 0x00005120 File Offset: 0x00003320
		internal static string smethod_0(string string_0, string string_1)
		{
			byte[] bytes = Encoding.Unicode.GetBytes(string_0);
			byte[] array = new byte[]
			{
				82, 102, 104, 110, 32, 77, 24, 34, 118, 181,
				51, 17, 18, 51, 12, 109, 10, 32, 77, 24,
				34, 158, 161, 41, 97, 28, 118, 181, 5, 25,
				1, 88
			};
			byte[] array2 = Class3.smethod_9(Encoding.Unicode.GetBytes(string_1));
			MemoryStream memoryStream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = Class3.smethod_7();
			symmetricAlgorithm.Key = array;
			symmetricAlgorithm.IV = array2;
			CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(bytes, 0, bytes.Length);
			cryptoStream.Close();
			return Convert.ToBase64String(memoryStream.ToArray());
		}
	}

	// Token: 0x02000013 RID: 19
	// (Invoke) Token: 0x06000065 RID: 101
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	internal delegate uint Delegate2(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

	// Token: 0x02000014 RID: 20
	// (Invoke) Token: 0x06000069 RID: 105
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate3();

	// Token: 0x02000015 RID: 21
	internal struct Struct1
	{
		// Token: 0x04000046 RID: 70
		internal bool bool_0;

		// Token: 0x04000047 RID: 71
		internal byte[] byte_0;
	}

	// Token: 0x02000016 RID: 22
	internal class Class6
	{
		// Token: 0x0600006C RID: 108 RVA: 0x000024CE File Offset: 0x000006CE
		public Class6(Stream stream_0)
		{
			this.binaryReader_0 = new BinaryReader(stream_0);
		}

		// Token: 0x0600006D RID: 109 RVA: 0x000024E2 File Offset: 0x000006E2
		internal Stream method_0()
		{
			return this.binaryReader_0.BaseStream;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x000024EF File Offset: 0x000006EF
		internal byte[] method_1(int int_0)
		{
			return this.binaryReader_0.ReadBytes(int_0);
		}

		// Token: 0x0600006F RID: 111 RVA: 0x000024FD File Offset: 0x000006FD
		internal int method_2(byte[] byte_0, int int_0, int int_1)
		{
			return this.binaryReader_0.Read(byte_0, int_0, int_1);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x0000250D File Offset: 0x0000070D
		internal int method_3()
		{
			return this.binaryReader_0.ReadInt32();
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000251A File Offset: 0x0000071A
		internal void method_4()
		{
			this.binaryReader_0.Close();
		}

		// Token: 0x04000048 RID: 72
		private BinaryReader binaryReader_0;
	}

	// Token: 0x02000017 RID: 23
	// (Invoke) Token: 0x06000073 RID: 115
	[UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi)]
	private delegate IntPtr Delegate4(IntPtr hModule, string lpName, uint lpType);

	// Token: 0x02000018 RID: 24
	// (Invoke) Token: 0x06000077 RID: 119
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate5(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

	// Token: 0x02000019 RID: 25
	// (Invoke) Token: 0x0600007B RID: 123
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate6(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

	// Token: 0x0200001A RID: 26
	// (Invoke) Token: 0x0600007F RID: 127
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate7(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

	// Token: 0x0200001B RID: 27
	// (Invoke) Token: 0x06000083 RID: 131
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate IntPtr Delegate8(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

	// Token: 0x0200001C RID: 28
	// (Invoke) Token: 0x06000087 RID: 135
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate int Delegate9(IntPtr ptr);

	// Token: 0x0200001D RID: 29
	[Flags]
	private enum Enum0
	{

	}
}
