﻿using System;

// Token: 0x0200001E RID: 30
internal class Class7
{
	// Token: 0x0400004A RID: 74
	private static bool bool_0;
}
