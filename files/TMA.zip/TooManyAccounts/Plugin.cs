﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using BepInEx;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using MonoMod.RuntimeDetour;
using Newtonsoft.Json.Linq;
using Photon.Pun;
using PlayFab;
using PlayFab.Internal;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

// Token: 0x02000007 RID: 7
[BepInPlugin("UYZEFIOUYAZEIOUZEYFUIO", "HJFHJKZEFLHJZEFHLJK", "1.1.7")]
public class Plugin : BaseUnityPlugin
{
	// Token: 0x0600000D RID: 13 RVA: 0x0000226B File Offset: 0x0000046B
	internal static void PrefixAuth(object __instance)
	{
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000226B File Offset: 0x0000046B
	internal static void PrefixLegal(object __instance)
	{
	}

	// Token: 0x0600000F RID: 15 RVA: 0x00002840 File Offset: 0x00000A40
	public static void MakeApiCallPatch(Action<PlayFabUnityHttp, object> old, PlayFabUnityHttp __instance, object container)
	{
		CallRequestContainer callRequestContainer = container as CallRequestContainer;
		if (callRequestContainer != null)
		{
			Plugin.<>c__DisplayClass4_0 CS$<>8__locals1 = new Plugin.<>c__DisplayClass4_0();
			CS$<>8__locals1.action_0 = callRequestContainer.ErrorCallback;
			callRequestContainer.ErrorCallback = new Action<PlayFabError>(CS$<>8__locals1.method_0);
		}
		if (Plugin.bool_0)
		{
			return;
		}
		old(__instance, container);
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000226D File Offset: 0x0000046D
	internal static void PrefixSetCustomAuthParams(Action<PhotonAuthenticator, Dictionary<string, object>> old, object __instance, Dictionary<string, object> customAuthData)
	{
		ExtensionMethods.AddOrUpdate<string, object>(customAuthData, "Platform", "Quest");
		old(__instance, customAuthData);
	}

	// Token: 0x06000011 RID: 17 RVA: 0x0000288C File Offset: 0x00000A8C
	internal static Task PrefixNonce(NetworkSystem networkSystem)
	{
		Plugin.<>c__DisplayClass6_0 CS$<>8__locals1 = new Plugin.<>c__DisplayClass6_0();
		CS$<>8__locals1.networkSystem_0 = networkSystem;
		CS$<>8__locals1.bool_0 = false;
		if (Plugin.bool_0)
		{
			NetworkSystemPUN networkSystemPUN = CS$<>8__locals1.networkSystem_0 as NetworkSystemPUN;
			if (networkSystemPUN != null)
			{
				networkSystemPUN.ResetSystem();
			}
			Plugin.smethod_2();
			CS$<>8__locals1.bool_0 = true;
		}
		return Task.Run(new Func<Task>(CS$<>8__locals1.method_0));
	}

	// Token: 0x06000012 RID: 18 RVA: 0x000028F0 File Offset: 0x00000AF0
	protected void Awake()
	{
		MethodBase method = typeof(NetworkSystem).GetMethod("RefreshNonce", BindingFlags.Instance | BindingFlags.NonPublic);
		MethodInfo method2 = typeof(PlayFabAuthenticator).GetMethod("AuthenticateWithPlayFab");
		MethodInfo method3 = typeof(LegalAgreements).GetMethod("Awake", BindingFlags.Instance | BindingFlags.NonPublic);
		MethodInfo method4 = typeof(PhotonAuthenticator).GetMethod("SetCustomAuthenticationParameters");
		MethodInfo method5 = typeof(PlayFabUnityHttp).GetMethod("MakeApiCall");
		new Hook(method, typeof(Plugin).GetMethod("PrefixNonce", BindingFlags.Static | BindingFlags.NonPublic)).Apply();
		new Hook(method2, typeof(Plugin).GetMethod("PrefixAuth", BindingFlags.Static | BindingFlags.NonPublic)).Apply();
		new Hook(method3, typeof(Plugin).GetMethod("PrefixLegal", BindingFlags.Static | BindingFlags.NonPublic)).Apply();
		new Hook(method4, typeof(Plugin).GetMethod("PrefixSetCustomAuthParams", BindingFlags.Static | BindingFlags.NonPublic)).Apply();
		new Hook(method5, typeof(Plugin).GetMethod("MakeApiCallPatch")).Apply();
		Plugin.string_0 = Class1.smethod_0();
	}

	// Token: 0x06000013 RID: 19 RVA: 0x00002A20 File Offset: 0x00000C20
	private void method_0()
	{
		if (!Class1.bool_2)
		{
			return;
		}
		if (!Class1.bool_0)
		{
			return;
		}
		if (!PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			if (GUI.Button(new Rect((float)(Screen.width / 2 - 100), 20f, 200f, 30f), "GET MASTER ;)"))
			{
				PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
			}
			return;
		}
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002A80 File Offset: 0x00000C80
	protected void OnGUI()
	{
		this.method_0();
		if (!(Plugin.string_0 == "good"))
		{
			GUI.BeginGroup(new Rect((float)(Screen.width / 2 - 200), (float)(Screen.height / 2 - 150), 400f, 150f));
			GUI.Box(new Rect(0f, 0f, 400f, 150f), "There was an error, try re-installing using the installer.");
			GUI.EndGroup();
			return;
		}
	}

	// Token: 0x06000015 RID: 21 RVA: 0x00002B00 File Offset: 0x00000D00
	protected void Update()
	{
		if (Keyboard.current.insertKey.wasPressedThisFrame)
		{
			Class1.bool_2 = !Class1.bool_2;
		}
		if (!Player.Instance || Class1.bool_1)
		{
			return;
		}
		if (Plugin.string_0 == "good")
		{
			Class1.bool_1 = true;
			Plugin.smethod_2();
			return;
		}
		string text;
		new Dictionary<string, string> { { "folder", "The TMA Folder is not found. Make sure you dragged the entire folder and not just the TooManyAccounts File!" } }.TryGetValue(Plugin.string_0, out text);
		Plugin.smethod_1(text ?? "There was an error, try re-installing using the installer.");
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00002B90 File Offset: 0x00000D90
	private static void smethod_0(string string_1, string string_2)
	{
		TMP_Text component = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text").GetComponent<TextMeshPro>();
		GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct").GetComponent<TextMeshPro>().text = string_1;
		component.text = string_2;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00002BC8 File Offset: 0x00000DC8
	private static void smethod_1(string string_1)
	{
		Plugin.smethod_0("ERROR", "[TooManyAccounts] " + string_1);
		GameObject gameObject = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom");
		Material material = new Material(Shader.Find("GorillaTag/UberShader"))
		{
			color = new Color(0.5f, 0f, 0f)
		};
		for (int i = 0; i < gameObject.transform.childCount; i++)
		{
			GameObject gameObject2 = gameObject.transform.GetChild(i).gameObject;
			if (gameObject2.name.StartsWith("UnityTempFile"))
			{
				gameObject2.GetComponent<Renderer>().material = material;
			}
		}
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002C74 File Offset: 0x00000E74
	private static void smethod_2()
	{
		try
		{
			WebHeaderCollection webHeaderCollection = new WebHeaderCollection();
			webHeaderCollection.Set("key", Class1.string_0);
			webHeaderCollection.Set("hwid", SystemInfo.deviceUniqueIdentifier);
			webHeaderCollection.Set("nonce", Class1.string_1);
			webHeaderCollection.Set("version", "1.1.7");
			JObject jobject = Class1.class0_0.method_0("doFun", webHeaderCollection);
			Class1.smethod_1((string)jobject["nonce"]);
			webHeaderCollection.Set("nonce", Class1.string_1);
			JObject jobject2 = Class1.class0_0.method_0("doFun?refreshToken=true", webHeaderCollection);
			Class1.smethod_1((string)jobject2["nonce"]);
			JToken jtoken = jobject["tokenInfos"];
			(string)jtoken["id"];
			string text = (string)jtoken["osid"];
			(string)jtoken["token"];
			string text2 = (string)jtoken["ticket"];
			string text3 = (string)jtoken["eToken"];
			string text4 = (string)jtoken["pId"];
			string text5 = (string)jtoken["eId"];
			string text6 = (string)jtoken["eType"];
			string text7 = (string)jobject2["token"];
			Traverse traverse = Traverse.Create(PlayFabAuthenticator.instance);
			PlayFabSettings.staticPlayer = new PlayFabAuthenticationContext(text2, text3, text4, text5, text6);
			traverse.Field("_orgScopedId").SetValue(text);
			traverse.Field("_playFabPlayerIdCache").SetValue(text4);
			traverse.Field("_sessionTicket").SetValue(text2);
			traverse.Field("_nonce").SetValue(text7);
			traverse.Method("AuthenticateWithPhoton", Array.Empty<object>()).GetValue();
			Plugin.bool_0 = false;
			Class1.bool_0 = true;
			Plugin.smethod_0("TOO MANY ACCOUNTS T.O.S", "- Don't try to crack / reverse engineer the .dll plugin\n- Don't distribute the .dll plugin\n- Have Fun!\n\nIF YOU ENJOY TOO MANY ACCOUNTS, TALK ABOUT IT TO YOUR FRIENDS!\n\ndiscord.gg/hXxCa9gT9q");
		}
		catch (WebException ex)
		{
			if (ex.Status != WebExceptionStatus.ProtocolError)
			{
				Console.WriteLine(string.Format("Failed to complete request. Will retry in 1second. Got ${0}", ex.Status));
				Thread.Sleep(1000);
				Plugin.smethod_2();
			}
			else
			{
				HttpWebResponse httpWebResponse = ex.Response as HttpWebResponse;
				if (httpWebResponse != null)
				{
					JObject jobject3 = JObject.Parse(new StreamReader(httpWebResponse.GetResponseStream()).ReadToEnd());
					if (httpWebResponse.StatusCode == HttpStatusCode.Forbidden)
					{
						JToken jtoken2 = jobject3["banData"]["BanMessage"];
						Plugin.smethod_1(string.Format("This gtag account is banned: {0}\n\nUnable to login, please use another account.", jtoken2));
					}
					else
					{
						Plugin.smethod_1((string)jobject3["message"]);
					}
				}
			}
		}
	}

	// Token: 0x04000011 RID: 17
	private static string string_0;

	// Token: 0x04000012 RID: 18
	private static bool bool_0;
}
