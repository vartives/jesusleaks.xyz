﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyProduct("FGHJKZEFKHJGZEFKGHJ")]
[assembly: AssemblyInformationalVersion("1.0.0+25f5ffa229896b9f1b33ca4353a76f7b3ca307a3")]
[assembly: SuppressIldasm]
[assembly: AssemblyTitle("FGHJKZEFKHJGZEFKGHJ")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("FGHJKZEFKHJGZEFKGHJ")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
[module: RefSafetyRules(11)]
