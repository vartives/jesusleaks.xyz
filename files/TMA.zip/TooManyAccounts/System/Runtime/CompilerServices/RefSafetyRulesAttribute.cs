﻿using System;
using Microsoft.CodeAnalysis;

namespace System.Runtime.CompilerServices
{
	// Token: 0x02000003 RID: 3
	[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
	[Embedded]
	[CompilerGenerated]
	internal sealed class RefSafetyRulesAttribute : Attribute
	{
		// Token: 0x06000002 RID: 2 RVA: 0x0000253C File Offset: 0x0000073C
		public RefSafetyRulesAttribute(int int_0)
		{
			this.Version = int_0;
		}

		// Token: 0x04000001 RID: 1
		public readonly int Version;
	}
}
